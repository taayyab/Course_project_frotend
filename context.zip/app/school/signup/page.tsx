import AuthForm from "@/components/AuthForm";
export default function Page() {
  return <AuthForm role="school" type="signup" />;
}
