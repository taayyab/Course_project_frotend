"use client";

import { useEffect, ReactNode } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "./AuthContext";

interface ProtectedRouteProps {
  children: ReactNode;
  role?: string; // e.g., "admin", "user", etc.
}

export default function ProtectedRoute({ children, role }: ProtectedRouteProps) {
  const { token, user } = useAuth(); // Get user object as well
  const router = useRouter();

  useEffect(() => {
    if (!token) {
      // Redirect to role-specific login page if role is provided
      if (role) {
        router.push(`/${role}/login`);
      } else {
        router.push("/login");
      }
    } else {
      // If token exists, check if user's role matches the expected role for this route
      if (role && user && user.role && user.role !== role) {
        // Redirect to user's actual dashboard if roles don't match
        router.push(`/${user.role}/dashboard`);
      }
    }
  }, [token, user, router, role]); // Add user to dependency array

  return token ? <>{children}</> : null;
}
