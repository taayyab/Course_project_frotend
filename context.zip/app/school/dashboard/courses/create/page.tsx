"use client"

import { AppShell } from "@/components/institute/app-shell"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/institute/ui/card"
import { Button } from "@/components/institute/ui/button"
import { Input } from "@/components/institute/ui/input"
import { Textarea } from "@/components/institute/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/institute/ui/select"
import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function CreateCoursePage() {
  const router = useRouter()
  return (
    <AppShell>
      <div className="px-4 lg:px-8 py-6">
         <button
          type="button"
          onClick={() => router.push("/school/dashboard/courses")}
          className="mb-4 flex items-center gap-2 text-[#0755E9] focus:outline-none decoration-none cursor-pointer"
        >
          <ArrowLeft className="h-5 w-5" />
          <span className="font-medium">Back to Courses</span>
        </button>
        <Card className="shadow-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Create New Course</CardTitle>
            <CardDescription>Fill in the details below to create a new course for your students.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1 block text-sm font-medium text-[#3f3f3f]">Course Title</label>
                <Input placeholder="e.g. Advanced Python for Data Science" />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-[#3f3f3f]">Instructor name</label>
                <Input placeholder="e.g. Dr. Sara Chen" />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-[#3f3f3f]">Course Duration</label>
                <Input placeholder="e.g. 8 Weeks" />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-[#3f3f3f]">Course Price</label>
                <Input placeholder="$ 199" />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-[#3f3f3f]">Language</label>
                <Select defaultValue="en">
                  <SelectTrigger><SelectValue placeholder="Select Language" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="es">Spanish</SelectItem>
                    <SelectItem value="fr">French</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-[#3f3f3f]">Course Type</label>
                <Select defaultValue="online">
                  <SelectTrigger><SelectValue placeholder="Select Course Type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="online">Online</SelectItem>
                    <SelectItem value="hybrid">Hybrid</SelectItem>
                    <SelectItem value="onsite">Onsite</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-[#3f3f3f]">Course Description</label>
              <Textarea rows={6} placeholder="Full Course introduction and Summary" />
            </div>

            {["Learning Objectives", "Learning Objectives", "Skills You'll Learn"].map((label, i) => (
              <div key={i}>
                <label className="mb-1 block text-sm font-medium text-[#3f3f3f]">{label}</label>
                <Input placeholder="Add Learning Objectives" />
              </div>
            ))}

            <div className="flex items-center justify-end gap-3">
              <Button variant="secondary" className="rounded-full bg-[#f3f6ff] text-[#0a60ff]">Save Draft</Button>
              <Button className="rounded-full">Create Course</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  )
}
