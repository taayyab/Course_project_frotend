import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

const protectedRoutes = {
  admin: ["/admin/dashboard"],
  employer: ["/employer/dashboard"],
  school: ["/school/dashboard"],
  student: ["/student/dashboard"],
};



export function middleware(request: NextRequest) {
  const userRole = request.cookies.get('user_role')?.value;
  const { pathname } = request.nextUrl;

  const publicPaths = ['/', '/admin/login', '/admin/signup', '/employer/login', '/employer/signup', '/school/login', '/school/signup', '/student/login', '/student/signup'];
  const roleDashboards: { [key: string]: string } = {
    admin: '/admin/dashboard',
    employer: '/employer/dashboard',
    school: '/school/dashboard',
    student: '/student/dashboard',
  };

  // NEW: If user is logged in and on the root path, redirect to their dashboard
  if (userRole && pathname === '/') {
    return NextResponse.redirect(new URL(roleDashboards[userRole], request.url));
  }

  // 1. If user is logged in and tries to access login/signup, redirect to their dashboard
  if (userRole && (pathname.includes('/login') || pathname.includes('/signup'))) {
    return NextResponse.redirect(new URL(roleDashboards[userRole], request.url));
  }

  // If the user is trying to access a public path, allow it
  if (publicPaths.includes(pathname)) {
    return NextResponse.next();
  }

  // If no user role, and the path is not a public path, redirect to the appropriate login page
  if (!userRole) {
    if (pathname.startsWith('/admin')) {
      return NextResponse.redirect(new URL('/admin/login', request.url));
    }
    if (pathname.startsWith('/employer')) {
      return NextResponse.redirect(new URL('/employer/login', request.url));
    }
    if (pathname.startsWith('/school')) {
      return NextResponse.redirect(new URL('/school/login', request.url));
    }
    if (pathname.startsWith('/student')) {
      return NextResponse.redirect(new URL('/student/login', request.url));
    }
    // If it's not a recognized protected path, redirect to home
    return NextResponse.redirect(new URL('/', request.url));
  }

  // Role-specific access control
  if (pathname.startsWith('/admin') && userRole !== 'admin') {
    return NextResponse.redirect(new URL('/admin/login', request.url));
  }
  if (pathname.startsWith('/employer') && userRole !== 'employer') {
    return NextResponse.redirect(new URL('/employer/login', request.url));
  }
  if (pathname.startsWith('/school') && userRole !== 'school') {
    return NextResponse.redirect(new URL('/school/login', request.url));
  }
  if (pathname.startsWith('/student') && userRole !== 'student') {
    return NextResponse.redirect(new URL('/student/login', request.url));
  }

  // If authorized, proceed
  return NextResponse.next();
}


export const config = {
  matcher: [
    "/admin/dashboard/:path*",
    "/employer/dashboard/:path*",
    "/school/dashboard/:path*",
    "/student/dashboard/:path*",
    "/admin/login",
    "/employer/login",
    "/school/login",
    "/student/login",
    "/admin/signup",
    "/employer/signup",
    "/school/signup",
    "/student/signup",
  ],
};
