export default function SettingsLayout({ children }: { children: React.ReactNode }) {
  return <div className="pt-6">{children}</div>
}
