"use client"

import { useRouter } from "next/navigation"
import { ArrowLeft } from 'lucide-react'
import { Button } from "@/components/employer/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/employer/ui/card"
import { Input } from "@/components/employer/ui/input"
import { Textarea } from "@/components/employer/ui/textarea"
import { Label } from "@/components/employer/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/employer/ui/select"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

export default function CreateJobPostPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [form, setForm] = useState({
    title: "",
    department: "",
    location: "",
    employment: "Full-time",
    salaryMin: "",
    department2: "",
    description: "",
    requirements: "",
    perks: "",
  })

  function submit() {
    if (!form.title || !form.location || !form.salaryMin || !form.description || !form.requirements) {
      toast({ title: "Please complete required fields", variant: "destructive" as any })
      return
    }
    toast({ title: "Job post published", description: "This is dummy data; wire up your API later." })
    router.push("/job-posts")
  }

  return (
    <div className="pt-6">
      <button onClick={() => router.push("/employer/job-posts")} className="inline-flex items-center gap-2 text-[#3f3f3f]">
        <ArrowLeft className="h-4 w-4" /> Back to Job Posts
      </button>

      <Card className="mt-4 bg-white/80 border-[#e6e7ef]">
        <CardHeader>
          <CardTitle>Create New Job Post</CardTitle>
          <CardDescription>Fill out the details for your new job posting</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Field label="Job Title *">
              <Input placeholder="e.g. Senior Frontend Developer" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
            </Field>
            <Field label="Department *">
              <Input placeholder="e.g. Engineering" value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} />
            </Field>

            <Field label="Location *">
              <Input placeholder="e.g. San Francisco, CA or Remote" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} />
            </Field>
            <Field label="Employment Type *">
              <Select value={form.employment} onValueChange={v => setForm({ ...form, employment: v })}>
                <SelectTrigger><SelectValue placeholder="Full-time" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Full-time">Full-time</SelectItem>
                  <SelectItem value="Part-time">Part-time</SelectItem>
                  <SelectItem value="Contract">Contract</SelectItem>
                </SelectContent>
              </Select>
            </Field>

            <Field label="Salary Range (Min) *">
              <Input placeholder="65000" value={form.salaryMin} onChange={e => setForm({ ...form, salaryMin: e.target.value })} />
            </Field>
            <Field label="Department *">
              <Input placeholder="e.g. Engineering" value={form.department2} onChange={e => setForm({ ...form, department2: e.target.value })} />
            </Field>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Field label="Job Description *">
              <Textarea placeholder="Describe the role, responsibilities, and what makes this position exciting …" className="min-h-[140px]" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
            </Field>
            <Field label="Requirements *">
              <Textarea placeholder="List the required skills, experience, and qualifications …" className="min-h-[140px]" value={form.requirements} onChange={e => setForm({ ...form, requirements: e.target.value })} />
            </Field>
          </div>

          <Field label="Benefits & Perks">
            <Textarea placeholder="Health insurance, 401k, flexible hours, remote work options …" value={form.perks} onChange={e => setForm({ ...form, perks: e.target.value })} />
          </Field>

          <div className="flex gap-3">
            <Button onClick={submit} className="bg-[#0f5ff2] hover:bg-[#0d4fe0]">Publish Job Post</Button>
            <Button variant="outline" className="border-[#e6e7ef]" onClick={() => router.push("/job-posts")}>Cancel</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid gap-2">
      <Label>{label}</Label>
      {children}
    </div>
  )
}
