import axios from "axios"

export const API_BASE_URL = "http://localhost:4000"

export const signup = async (role: string, fullName: string, email: string, phone: string, password: string) => {
  try {
    const res = await axios.post(`${API_BASE_URL}/api/v1/users/register`, {
      role,
      fullName,
      email,
      phone,
      password,
    })
    return res.data
  } catch (err: any) {
    throw new Error(err.response?.data?.message || "Signup failed")
  }
}

export const signin = async (email: string, password: string) => {
  try {
    const res = await axios.post(`${API_BASE_URL}/api/v1/users/login`, {
      email,
      password,
    })
    return res.data
  } catch (err: any) {
    throw new Error(err.response?.data?.message || "Signin failed")
  }
}

export const logout = async () => {
  return axios.post(`${API_BASE_URL}/api/v1/users/logout`, {}, { withCredentials: true })
}
