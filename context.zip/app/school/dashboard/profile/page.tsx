"use client"

import { AppShell } from "@/components/institute/app-shell"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/institute/ui/card"
import { Button } from "@/components/admin/ui/button"
import { CourseCard } from "@/components/institute/course-card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/institute/ui/avatar"

export default function ProfilePage() {
  return (
    <AppShell>
      <div className="px-4 lg:px-8 py-6">
        <h1 className="text-2xl font-semibold text-[#1e242c]">Profile</h1>
        <p className="mt-1 text-[#696984]">Facilitate industry partnerships and manage employer relationships</p>

        <Card className="mt-5 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src="/placeholder.svg?height=48&width=48" alt="Harvard University" />
                  <AvatarFallback>HU</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-semibold text-[#1e242c]">Harvard University</div>
                  <div className="text-sm text-[#696984]">Email Address: oliviaryhyne@gmail</div>
                  <div className="text-sm text-[#696984]">Contact: 066-7778-9</div>
                </div>
              </div>
              <Button className="rounded-lg">Edit</Button>
            </div>
          </CardContent>
        </Card>

        <Card className="mt-4 shadow-sm">
          <CardHeader>
            <CardTitle className="text-[#1e242c]">About</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-[#3f3f3f]">
            <p>
              Founded with the mission to bridge the skills gap, our training institute offers professional training programs designed by industry experts. Whether you’re a student, professional, or business, we help you build real-world capabilities through hands-on learning.
            </p>
            <p><span className="font-medium">Established:</span> 2015</p>
            <p><span className="font-medium">Location:</span> Karachi, Pakistan</p>
            <p><span className="font-medium">Focus Areas:</span> Tech, Business, Design, Soft Skills</p>
          </CardContent>
        </Card>

        <div className="mt-6 flex items-center justify-between">
          <div className="font-semibold text-[#1e242c]">Explore best courses <span className="text-[#0a60ff]">6</span></div>
          <Button variant="secondary" className="rounded-full bg-[#f6f8ff] text-[#0755e9]">View ALL</Button>
        </div>
        <div className="mt-3 grid grid-cols-1 gap-6 lg:grid-cols-2">
          <CourseCard />
          <CourseCard />
        </div>
      </div>
    </AppShell>
  )
}
