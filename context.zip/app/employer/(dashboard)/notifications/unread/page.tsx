import { NotificationsInner } from "../page"

export default function UnreadTab() {
  return <NotificationsInner filter="unread" />
}
